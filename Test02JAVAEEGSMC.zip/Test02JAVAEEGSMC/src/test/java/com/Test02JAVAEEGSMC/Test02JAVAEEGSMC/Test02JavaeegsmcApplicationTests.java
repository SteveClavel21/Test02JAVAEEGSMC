package com.Test02JAVAEEGSMC.Test02JAVAEEGSMC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Test02JavaeegsmcApplicationTests {

	@Test
	void contextLoads() {
	}

}
