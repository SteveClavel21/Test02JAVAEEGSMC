package com.Test02JAVAEEGSMC.Test02JAVAEEGSMC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Test02JavaeegsmcApplication {

	public static void main(String[] args) {
		SpringApplication.run(Test02JavaeegsmcApplication.class, args);
	}

}
